#ifndef CODECONSTANT_H
#define CODECONSTANT_H


extern double INV_RAND_MAX ;
extern double INV_RAND_MAX1;


#endif
