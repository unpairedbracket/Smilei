#ifndef DiagnosticProbe0D_H
#define DiagnosticProbe0D_H

#include <cmath>

#include <vector>
#include <string>
#include <iostream>
#include <fstream>

#include <hdf5.h>

#include "Tools.h"

#include "Species.h"
#include "Interpolator.h"
#include "Particles.h"

class PicParams;
class SmileiMPI;
class DiagParams;
class ElectroMagn;

class DiagnosticProbe0D {

public:

    DiagnosticProbe0D(PicParams* params, DiagParams* diagParams, SmileiMPI* smpi);
    ~DiagnosticProbe0D();

    void set_proc();
    void set_file_name();

    void run(int timestep, ElectroMagn* EMfields, Interpolator* interp);

    std::string probeName(int p);
    void open_file();
    void close();

private:
    SmileiMPI* smpi_;

    hid_t fileId;
    Particles probeParticles;
    std::vector<int> probeId;
    LocalFields Eloc_fields;
    LocalFields Bloc_fields;
    int probeSize;

};
#endif
