PIC algorithms
--------------

.. rst-class:: inprogress
  
  In progress ...
