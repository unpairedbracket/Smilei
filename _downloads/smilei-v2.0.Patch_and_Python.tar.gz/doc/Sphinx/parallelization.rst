Parallelization
---------------

.. rst-class:: inprogress
  
  In progress ...
